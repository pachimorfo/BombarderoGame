/*
 * Carlos Sanchez Bouza
 * Ángel Romero Pareja
 *
 * Videojuegos en dispositivos moviles
 *
 */

package ucm.gdv.panda.minterfaz;

public interface Image {
    //Getters para el tamaño de la imagen
    int getWidth();
    int getHeight();
}
